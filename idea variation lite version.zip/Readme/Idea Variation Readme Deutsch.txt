###################################################################
###################################################################
####### Idea Variation Mod by flogi
###################################################################
###################################################################

###################################################################
####### Version 3.3.1 (1420)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Geb�ude so angepasst, das es keine Probleme mehr mit Missions bzw. Event�berschneidungen geben sollte
- Autonomieedikt etwas g�nstiger gemacht
- Ein paar Lokalisationsfehler gefixt
- Verbesserte Ideenbeschreibung (Englisch) (Danke an Picasso Sparks)
- St�nde und Parlamentssitz k�nnen in der gleichen Provinz sein
- Der Rat bekommt keinen Einfluss von St�nden mehr, daf�r jetzt von Beratern, die alle eine Affinit�t zu einem Stand bekommen haben (war notwendig, weil es wenn 3 oder mehr St�nde illoyal waren zu dem Ergebnis f�hren konnte das einfach ein Stand den gesamten Einfluss bekommen hat)

###################################################################
####### Geb�ude
###################################################################

- Handelsgeb�ude Reihe etwas gebuffed
- Land Forcelimit Geb�ude werden nicht mehr gel�scht wenn man ein Land erobert, aber man braucht weiterhin ein Staatsgebiet um sie ausbauen zu k�nnen

###################################################################
####### Regierungsreformen & St�nde
###################################################################

- Projekt finanzieren und Gefallen gew�hren reduziert nicht mehr die Loyalit�t anderer St�nde
- Projekt finanzieren bringt nun 15 Loyalit�t
- Die Standboni von Regierungsreformen wurden gest�rkt (Loyalit�t)
- Die Regierungsreformen reduzieren etwas weniger Legitimit�t, Rep Tradition und Devotion
- Man verliert nun keine Reformen mehr wenn man radikal die Regierung wechselt. Daf�r hat man 10 Jahre geringeres Reformwachstum; Au�erdem kostet es 3 Stab

###################################################################
####### Version 3.3.0 (2379)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Einheiten verlieren keinen Drill mehr wenn sie einfach nur rumstehen. Durch Verluste verlieren sie nat�rlich Drill.
- Die russische Streltsy Aktion bringt nun nur noch von 15% des Truppenlimits Infanterie
- Hardmode (KI Boni) gibt nun kostenlose Politiken f�r die KI
- Die Late Game Festungsgeb�ude ein wenig nach hinten geschoben
- Die maximale Attrition, die die Festungsgeb�ude geben wurde reduziert 
- Fixed: Development Malus f�r Provinzen in Staatsgebieten verschwand wenn man �ber 152 hatte
- Eine Regierungsreform wechseln kostet nun statt 10 Korruption 5 Korruption und einen Stabilit�tspunkt
- Regimenter bekommen nun durch Drill 10 Diszi, statt dem anderen Zeug
- Die Auswirkungen von Legitimit�t etwas gest�rkt
- Innovativit�t bringt nun statt 10% auf alle Punktekosten bei 100%, 10% Techkosten, 10% Ideenkosten, 25 maximalen Absolutismus, +1 Absolutismus, 3 Splendor
- Es gibt keine freien Basispolitiken mehr
- Kavallerie bekommt im Lategame mehr Fire
- Developmentkostenreduktion von Handelszentren im ganzen Staat entfernt
- Marine Kampf System etwas besser gebalanced, Im h�heren Zeitalter erh�ht sich die Frontbreite bei Marineschlachten

###################################################################
####### Regierungsreformen 
###################################################################

- Insgesamt �ber 80 neue Reformen hinzugef�gt (doppelte auf die alle Regierungsformen Zugriff haben nicht mitgez�hlt)
- Monarchien, Republiken und Theokratien haben komplett �berarbeitete Regierungseformb�ume
- Man kann nun schon auf Tier 1 seine Regierung komplett umkrempeln

###################################################################
####### St�nde
###################################################################

- St�nde System komplett �berarbeitet
- St�nde sind nur f�r die meisten Regierungsformen verf�gbar
- St�nde geben nun nur noch wirklich gute Boni wenn sie loyal sind
- Provinzen die von St�nden kontrolliert werden haben nun 0 Autonomie als Basis Einstellung. Ist der Stand loyal sinkt die Autonomie, ist er neutral steigt sie und ist er nicht loyal steigt sie deutlich.
- Provinzen die von St�nden kontrolliert werden geben nur gute Boni wenn der Stand loyal ist
- Viele neue Aktionen f�r alle St�nde
- Einige Vanilla Aktionen deutlich reworked

###################################################################
####### Ideen & Politiken
###################################################################

- Shock Ideen �berarbeitet
- Stehendes Heer hat nun verminderten Drillverlust durch Verluste von 50%
- Die Einflussideenpolitik bringt nun +25 Freiheitsstreben neben dem hohen Vasalleneinkommen
- Zentralismus bringt nur noch 33% Bauzeitbonus
- Man kann nicht mehr 100% Bauzeitreduktion durch Ideen und Politiken bekommen
- Die Justizideen geben nun neben republikanischer Tradition auch die anderen entsprechenden Boni f�r die Regierungsform (Adm Techkosten sind raus)
- Prestige aus Dynastieideen auf 1 erh�ht
- Missionarsunterhalt in religi�sen Ideen eingef�gt
- Einflussideen etwas generfed
- Republikideen geben nur noch 0.5 republikanische Tradition, daf�r 15% Reformfortschritt
- Propagandaideen haben 15 Regierungsreformfortschritt bekommen
- Die Imperialismus Politik (einzeln) von 100 Dauer Kerngebiete Verlust auf 50 gesenkt
- Innovativideen bringen nun 33% Regierungs Reformfortschritt (keine kostenlosen Politiken mehr)
- Minderheiten ausweisen bei Entdecker Ideen hinzugef�gt
- Imperialismus Forcelimit Boni etwas generfed
- Assimilation hat ein wenig Regierungs Reformfortschritt bekommen
- Taktik Ideen hat mehr Versorgungslimit bekommen

###################################################################
####### Version 3.2.2 (XXXX)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Kleinere Fixes
- Mehr Geb�udeslots hinzugef�gt. Daf�r Provinzinterface leicht �berarbeitet
- Wenn man die erh�hten Staatsverwaltungskosten f�r Geb�ude ausschaltet, schaltet man nun auch die erh�hten Entwicklungskosten aus


###################################################################
####### Version 3.2.1 (XXXX)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Spieldateien an den neuen Patch angepasst
- Berater Interface noch etwas verbessert damit scrollen nun auch h�bsch ist
- Das Regierungsgeb�ude (Gerichtskette) ist nur noch einmal im Staat baubar, der Bonus des Geb�udes erstreckt sich aber auf den ganzen Staat.
  Wird das Geb�ude gebaut kann bis es fertig ist im Staat kein weiteres Geb�ude gebaut werden, au�erdem muss das Geb�ude von der niedrigsten Stufe immer aufgelevelt werden
- Edikte entsprechend an die neuen Gegebenheiten angepasst
- Die letzten 4 Entwicklungsdecision Stufen kosten einen festen Geldbetrag (250) statt 15% des Jahreseinkommens
- Reduzierter Moralschaden von Reserven aus Professionalismus entfernt, daf�r 10% Belagerungseffizienz
- Belagerungseffizienz aus den skallierten Boni von Professionalismus entfernt
- Ein paar kleinere Berateranpassungen
- Die vordefinierten L�nderideengruppen wurden gel�scht sodass die KI frei Gruppen picken kann
- F�r sp�tere Startdates gibt es Ideenkostenboni wenn eine Nation vor einem bestimmten Zeitpunkt nicht X viele Ideengruppen hat
- Man kann nun aus jeder Kategorie 4 Politiken w�hlen, maximal 12

###################################################################
####### Ideen & Politiken
###################################################################

- Politiksystem entsprechend den Voraussetzungen der neuen Version komplett �berarbeitet
- 58 neue spezielle 1 Ideengruppen Politiken hinzugef�gt (nicht wundern, man braucht nur eine Idee zu komplettieren, aber wegen Interface Zw�ngen muss der Tooltip etwas verwirrend sein)
- Galleeren Fokus hat nun pro Zeitalter 100 Forcelimit mehr
- Die Flat Forcelimit Boni aus Kriegsproduktion sind nun auch nach Zeitalter skaliert
- Belagerungseffizienz aus Feuer Ideen entfernt
- Belagerungseffizienz aus Kriegsproduktion entfernt, 2.5% mehr Feuerschaden hinzugef�gt
- Einige Religi�se Ideengruppen etwas �berarbeitet
- Spionage und Imperialismus Ideen bringen nur noch 2.5% Disziplin
- Handelsschiffokus hat nun keine 10% Gro�schiff Kampffertigkeit mehr, daf�r etwas mehr Seeleuteunterhalt Reduktion
- Expansionsideen bringen nur noch 7 neue Staaten (vorher 10)
- Die Belagerungsboni aus den Flottenideen wurden in die neuen 1 Ideen Politiken verschoben
- Die Maritime Idee bringt nur noch 1 Bonus Man�ver f�r die Admir�le (vorher 2)
- Wenn man 50% Professionalismus hat und die S�ldneridee beendet ist bekommt man einen Professionalismus Verfall der je h�her der Professionalismus ist einsetzt
- Wahlmonarchien haben statt der Erben suchen Decision einen Modifier von 1 Prestige und + 1 Adm Punkten bei Herrschern bekommen
- Seefahrt Ideen etwas umgestellt; Die Endboni wurden in die spezielle Seefahrt Politik verschoben
- Innovativideen haben 1 freie Politik dazu bekommen, stattdessen die Techkosten verloren

###################################################################
####### Version 3.2.0 (304a)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Neuer Vasallisierungs Kriegsgrund (Imperialistische Ambitions Ideen) zur Vasallisierung von Nationen unter 150 Development
- Automatischer Ideengruppenwechsel f�r Religionen auf on_action umgestellt
- Automatischer Ideengruppenwechsel bei Religionswechsel f�r jede denkbare Kombination hinzugef�gt
- Automatischer Ideengruppenwechsel f�r die Regierungsformengruppen nun unsichtbar (per Event), au�erdem fehlende erg�nzt
- Die Imperalistische Ambitionsideen wechseln automatisch auf Imperialismusideen wenn man ein Kaiserreich wird
- Maritime War CB f�r KI deaktiviert weil sie damit nicht richtig klar kommt
- Verbesserte englische Beschreibung f�r Stehendes Heer & Generalstab (Danke an Big Boss Man)
- Staatsverwaltungskosten von Geb�uden nun Optional bei Spielstart deaktivierbar
- Janitscharen bekommen ab dem Jahr 1700 10 Basiseinfluss dazu
- Weitere kleinere Anpassungen

###################################################################
####### Ideen & Politiken
###################################################################

- 300 neue Ideengruppenspezifische Events hinzugef�gt f�r die neuen Ideen
- Neue Idee: Imperialistische Ambition f�r K�nigreiche, wird sp�ter ersetzt durch die Imperialismus Idee wenn sich der Rang auf Kaiserreich erh�ht
- Ideengruppen f�r nahuatl, mesoamerican, inti, totemism hinzugef�gt (damit hat jede Vanilla Religion ihre eigene Ideengruppe)
- Festungsidee etwas reworked
- Tengriidee: Pl�nderungsbonus entfernt
- Horde Ideen: Statt Pl�nderungsbonus gibt es nun 1 Diplomatische Reputation
- Flat Manpower Ideen und Politiken nach Zeitaltern skalliert (werden mit verstreichenden Zeitaltern st�rker)
- Imperiale Autorit�t und Mandat (Imperialismus Idee) nun nach Zeitaltern skaliert
- Farbige Punkte bei Ideengruppen hinzugef�gt um zu zeigen welche sich gegenseitig ausschlie�en

###################################################################
####### Geb�ude
###################################################################

- Kosten f�r die ersten drei Festungsgeb�ude (aus den Festungsideen) deutlich reduziert
- Die ersten beiden Geb�ude der Gerichtslinie kosten keinen Slot


###################################################################
####### Berater
###################################################################

- Minus Staatsverwaltungsberater von 30% auf 25% gesenkt
- 9 neue Beratertypen hinzugef�gt
- Brilliante Beraterevents f�r alle neuen Berater hinzugef�gt (32)
- Berater Interface �berarbeitet
- Skripted Berater Bonus auf 33% generfed (vorher 50)


###################################################################
####### Version 3.1.0 (2164)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Ein paar Lokalisationsfixes
- Hard Mode hat Marineboni bekommen
- Die KI Osmanen haben wegen Unf�higkeit einen kleinen Bonus bekommen (minus Korruption) um mit den Janitscharen fertig zu werden
- Ein paar kleinere Bugs gefixt
- Standboni aus den Ideen entfernt (funktionierte sowieso nicht sonderlich sinnvoll)
- Weitere kleinere Anpassungen

###################################################################
####### Geb�ude
###################################################################

- Nur noch Steuergeb�ude, Produktionsgeb�ude, Manufakturen und das Handelsgeb�ude erh�hen die Developmentkosten
- Staatsunterhaltkosten f�r fr�he Geb�ude deutlich reduziert
- Die Werften wurden etwas rebalanced
- Ein paar weitere kleinere Anpassungen

###################################################################
####### Ideen & Politiken
###################################################################

- Nochmal �ber alle Politiken r�bergeguckt und leichte Anpassungen gemacht (S�ldner Diszi eingef�gt z.B.)
- Gro�er Adm und Dip Ideen Fr�hjahrsputz, einige sinnlose Modifier entfernt
- Monarchie komplett reworked
- Aristokratie (nun Theokratie) komplett reworked
- Republik komplett reworked
- Spionageideen reworked
- Dynastieideen reworked
- Einflussideen leicht angepasst
- Expansion komplett reworked
- Administrative Ideen leicht angepasst
- Humanismus leicht angepasst
- Protestantismus leicht angepasst
- Reformiert leicht angepasst
- Islamideen leicht angepasst
- Orthodoxe Ideen angepasst
- Nordische Ideen leicht angepasst
- Shinto, Cathar und Hellenismus leicht angepasst
- Diktatur leicht angepasst
- Handelsschiffideen leicht angepasst
- Kolonialimperium Ideen komplett reworked
- Assimiliation leicht angepasst
- Propagandaideen leicht angepasst
- Flottenbasis reworked
- Imperialismus leicht angepasst
- Generalstab: Professionalismus etwas reduziert
- Stehendes Heer leicht angepasst
- Wehrpflicht leicht angepasst
- Kriegsproduktion leicht angepasst
- Staatsverwaltungsideen reworked
- Zentralismus leicht angepasst
- Militarismus leicht angepasst


###################################################################
####### Version 3.0.6 (XXXX)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Die erste Ediktstufe (Vanillalevel) ist wieder frei von Geb�udevoraussetzungen, ab der zweiten Geb�udestufe der Regierungsgeb�ude gibt es aber weiterhin bessere Edikte
- Der Siege Ability Berater bringt nun 20% siege ability (vorher 15)

###################################################################
####### Geb�ude
###################################################################

- Die Festungsgeb�ude kosten nun Staatsunterhalt
- Die sp�teren Stufen der Festungsgeb�ude sind massiv teurer geworden
- Die Steuermodifikatorgeb�ude etwas gebufft, die Produktionseffizienzgeb�ude ein klein wenig generfed

###################################################################
####### Ideen & Politiken
###################################################################

- Allgemein Defensivboni etwas reduziert
- Die Expansionsidee hat Siege Ability bekommen
- Die Humanismusidee bringt nun keine Korruptionsboni mehr
- Katholische, Protestantische, Reformierte und Islamische Ideen haben leichte Belagerungsboni bekommen
- Defensiv und Offensividee etwas umgestellt: Die Defensividee hat etwas fire damage received bekommen, die Offensividee daf�r den minus attrition bonus
- Die Militarismusidee hat -10 Land Attrition bekommen
- Die Kriegsproduktionsidee hat 5% Firedamage bekommen, daf�r die Produktionseffizienz verloren
- Die Fireidee hat +1 maximalen Artilleriebonus bekommen
- Die Propagandaidee hat 10% Belagerungseffizienz bekommen
- Die Galeerenidee bringt 15% Belagerungseffizienz
- Die Handelsschiffidee bringt +1 Belagerungsfortschritt wenn die Provinz vollst�ndig blockiert ist
- Die Gro�schiffidee bringt +1 maximalen Artilleriebonus beim Belagern
- Kolonialimperium liberty desire etwa angepasst (Paradox hat hier anscheinend die Berechnung des Wertes beim letzten Patch etwas ge�ndert)
- Ein paar Politiken bzgl siege ability und defensiveness angepasst

###################################################################
####### Version 3.0.5 (1842)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Die Buddhistische Religionsidee gilt nun auch f�r mahayana und vajrayana
- Die Edikte sind nun an die Verf�gbarkeit der Regierungsgeb�udereihe gekn�pft. Um ein Edikt aktivieren zu k�nnen braucht man in jeder dem Staat angeh�renden Provinz ein entsprechendes Geb�ude der Stufe
- Infanterie Fernkampf erh�ht (Tech 5 und Tech 11, jeweils um 0.25)
- Gro�e Kolinialnationen geben nun 5% Forcelimit Modifikator (Land) und 10% auf Marine (statt 5 bzw. 10 flat)
- Marken bringen nun 5% Forcelimit Modifikator und 10% mehr S�ldner f�r ihren Herren
- Vasallen bringen zus�tzlich 10% Marineforcelimit f�r ihren Herren
- Untergebene Nationen verlieren nicht mehr ihre 6 Offmap Basis Steuern

###################################################################
####### Geb�ude
###################################################################

- Die Developmentkostenreduktion des W�stengeb�udes wurde an den neuen Vanillawert angepasst
- Jedes Geb�ude erh�ht nun die lokalen Developmentkosten einer Provinz um 5%
- Fast jedes Geb�ude erh�ht die Staatsverwaltungskosten einer Provinz
- Landforcelimitgeb�ude k�nnen nur noch in Staatsgebieten gebaut werden
- Die Festungsideengeb�ude erh�hen nun die maximale Zerm�rbung in einer Provinz auf maximal 10


###################################################################
####### Ideen
###################################################################

- Hat man die S�ldnerheeridee abgeschlossen, kostet S�ldner rekrutieren kein Professionalismus mehr (daf�r kein j�hrlicher Professionalismus mehr)
- Die Shinto Ideen ein klein bisschen generfed

###################################################################
####### Version 3.0.4 (3192)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Dateien an den neuen Patch angepasst


###################################################################
####### Version 3.0.3 (c73e)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Die Modeinstellungen Events feuern nun mit Szenariostart
- Fixed: Einen Crash der bei der Handelshaus Decision (GB) auftrat
- Das Janitscharen Disaster auch von der Masse der Janitscharen abh�ngig gemacht
- Die Janitscharen erwarten nun die Kontrolle von Land welche nicht der muslimischen Religionsgruppe angeh�rt (�hnlich wie die Dhimmi)
- Events und Missionen an neue Geb�ude angepasst
- Spawns der Minister f�r die Kulturenmechaniken angepasst
- Ein neuer Miltech erh�ht den Landunterhalt nun um 4% (vorher 3)
- Staatsverwaltungskosten deutlich erh�ht per Development, daf�r den Malus auf fremden Kontinent etwas reduziert
- Grundzinsniveau auf 5% erh�ht (vorher 4)

###################################################################
####### Ideen
###################################################################

- Professionalismus Boni in Stehendes Heer, und S�ldnerheer
- Drill Bonus in Wehrpflicht
- Generalstabs hat Drill Bonus und j�hrlichen Professionalismus bekommen
- Die Imperialismus Ideen haben nun einen st�ndig tickenden Autorit�tsmodifikator f�r das HRR und einen Mandatsbonus
- Kleiner Mandatsbonus in den Konfuzianismus Ideen hinzugef�gt
- Die katholische Idee hat bringt nun 0.05 Reichsautorit�t/Monat und -50% Warscorekosten auf Religion erzwingen (Daf�r keine Legitimit�t mehr)

###################################################################
####### Geb�ude
###################################################################

- Prodktionsgeb�ude 3 und 4 etwas nach hinten geschoben
- Die meisten Geb�udekosten erh�ht
- Infrastrukturgeb�ude generfed
- Ein paar der Terraingeb�ude einen Tech fr�her verf�gbar  gemacht (haupts�chlich aus optischen Gr�nden)

###################################################################
####### Version 3.0.2 (52e3)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Fixed: Ein Problem mit den Developmentmodifikatoren
- Fixed: Ein Problem mit den neuen Kriegsgr�nden nach Syntax�nderung

###################################################################
####### Version 3.0.1 (e0da)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Fixed: Ein kleines Problem mit den Produktionsgeb�uden gefixt
- Fixed: Das zweite Festungsgeb�ude gibt nun Manpower wie es sollte
- Die Wehrpflichtidee gibt nun 15% Moral (nun gleichwertiger zu Stehendes Heer)
- Waffenqualit�tsideen etwas gest�rkt (gibt nicht mehr so viele gute Politiken, darum ist es nicht mehr schw�cher als Qualit�t)
- Nationalismus Idee: Schaltet nun den Nationalisten Stand frei (zus�tzlicher Buff f�r die Idee)
- 5 neue Berater hinzugef�gt (4 Dip, 1 Adm)
- Humanismus Decision entsprechend angepasst 

###################################################################
####### Version 3.0.0 (d173)
###################################################################

###################################################################
####### Allgemein
###################################################################
- Ein wenig alten Code entfernt
- Die Development Decision zeigt nun in allen Situationen den ben�tigten Geldbetrag an
- Das alte Erh�hte Projektkosten Modell entfernt, Development wird nun erst teurer wenn man 50 Staatsprovinzen kontrolliert
- Lokalisation an einigen Stellen verbessert (�bersichtlichkeit bei Ideen, vor allem bei den Modspeziellen Ideen)
- Ist man eine Diktatur, kann man die Diktatur nun behalten wenn man zwischen 20 und 60 republikanischer Tradition bleibt
- Marinekampfsystem ge�ndert: 60 Grundfrontbreite, keinen Moralschaden mehr wenn ein Schiff sinkt. Marineschlachten dauern deutlich l�nger und es gibt weniger Stackwipes. Insbesondere kann man rausziehen
- Idea Variation Hard Mode: Ein neuer Schwierigkeitsgrad f�r Leute, die eine Herausforderung suchen. Der Modus wird zu Beginn des Spiels per Event aktiviert
- Mod Einstellungen Events: Zu Beginn jedes Spiels kann man den Schwierigkeitsgrad bestimmen und �ber das Developmentsystem entscheiden


###################################################################
####### Ideen & Politiken
###################################################################

- 9 neue religi�se Ideengruppen (J�disch, Romuva, Slawisch, Hellenisch, Suomi, Zororastrisch, Fetischist, Animist, Manich�ismus)
- 2 neue Adminideen (Dezentralismus und Zentralismus, schlie�en sich gegenseitig aus)
- 2 neue Milit�rideen (Shock- und Fire Fokus, schlie�en sich gegenseitig aus)
- Galeeren, Handel und Gro�schiffideen Seeleute Unterhalt gebalanced
- Galeeren, Handel und Gro�schiffideen geben nun abh�ngig von dem Schiffstyp, den sie repr�sentieren je nachdem wie viele Schiffe man von dem Typ hat mehr Marinetradition
- Flottenbasis hat ebenfalls Minus Seeleuteunterhalt bekommen
- Quanit�tsideen deutlich verbessert
- Bei den Politiken gibt nun Qualit�t nicht mehr so viel Armeetradition, diese Politiken sind nun bei Generalstab
- Humanismus gebufft
- Die Humanismus Idee gibt eine neue Decision: Berater anheuern f�r verringerte Kosten, erh�ht aber allgemein Beraterkosten, Cooldown von 3 Jahren
- Humanismus gibt nun 7,5 Moral wenn man gleichzeitig 5 Kulturen akzeptiert hat
- Maritime Idee gebufft
- Neue Ideengruppe: Horde Ideen
- Handelsschifffokus wurde wieder etwas gest�rkt
- Galeerenfokus etwas abgeschw�cht, entsprechend zu dem neuen Marinesystem
- Die Diktaturidee hat eine Decision bekommen bei der man alle paar Jahre sich entscheiden kann ob man mehr in Richtung Monarchie oder Republik geht (oder Diktatur bleibt)
- ca 150 neue Politiken f�r die neuen Ideengruppen hinzugef�gt

###################################################################
####### Geb�ude
###################################################################

- Neues Geb�ude System, Vielen Dank an Marcin f�r die Geb�udebilder und das Interface
- Neue Geb�udekette: Infrastruktur
- Neue Geb�udekette: Terrain  Spezifische Geb�ude zur Erschlie�ung von Land (senken Development Kosten je nach Terrain)
- Produktion, Handel, Steuern, Armee und Regierung haben je eine weitere Geb�udestufe dazu bekommen
- Ideengruppenspezifische Geb�ude: Festungsgeb�ude f�r Festungsideen
- Ideengruppenspezifische Geb�ude: Marinebasen f�r Flottenbasis
- Ideengruppenspezifische Geb�ude: Spezielle Werften f�r Galeeren und Handel sowie f�r Gro�schiff Ideen

###################################################################
####### Version 2.5.4 (b94b)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Dateien an neuen Patch angepasst

###################################################################
####### Version 2.5.3 (4dd0)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Fixed: Rekruten fordern  vom Adelsstand brachte viel zu wenig M�nner
- Fixed: Die Development Decision wird nun keine Cores mehr ber�cksichtigen die man nicht mehr besitzt, sie erh�ht jetzt nur noch in Staaten das Development
- Als Voraussetzung f�r die Development Decision wird nun ein Geldbetrag angezeigt der nur minimal h�her ist, als das was man tats�chlich ausgeben muss

###################################################################
####### Version 2.5.2 (4dd0)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Dateien an neuen Patch angepasst

###################################################################
####### Version 2.5.1 (ea10)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Dynastieideen hei�en wieder wie sie sollen
- Harmonie zu Ideen und Politiken hinzugef�gt

###################################################################
####### Version 2.5.0 (XXXX)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Werte an den neuen Patch angepasst
- Es gibt Modifikatoren die die Developmentkosten durch Entwickeln steigen lassen wenn man eine gewisse Grundentwicklung erreicht hat (startet mit 700 bis 1500)
- Janitscharen sind nun ein Stand (f�r Leute mit Common Sense, f�r alle anderen bleibts beim Alten)
- Der (Vanilla) Staatennerv durch Technologie wurde etwas abgeschw�cht
- Extended Timeline Addon: Anfangsbuff auf Ideenkosten in den sp�teren Szenarien

###################################################################
####### Ideen, Berater & Politiken
###################################################################

- Die Entwicklungskostenpolitiken wurden so ge�ndert, dass man nun nur noch 2 gleichzeitig von ihnen aktiviert haben kann
- Die Politiken sind nun sofort im Spiel sichtbar, wenn man zwei Ideengruppen aktiviert hat (vorher musste man mindestens eine komplettieren)
- Die Orthodoxe Ideengruppe hat den Heiligen Krieg CB als Bonus wieder
- Islam Ideen wurden etwas gebufft
- Kolonialimperium hat 0.1 Malus auf Inflation bekommen
- Die Festungsidee bekommt als Bonus nochmal 10 defensiveness dazu
- S�ldnerheer hat statt Feuerschaden 5% S�ldnerdisziplin bekommen
- Islamideen bringt 10% mehr Kav ratio
- Monarchieideen bringt nun nur noch 10 cav to inf ratio anstatt moral und combat ability
- Monarchieideen bringen + 10 max Absolutismus und +1 j�hrlichen Absolutismus
- Taktikideen haben 20 cav to inf ratio bekommen
- Die Propagandaideen geben nun 1 j�hrlichen Absolutismus
- Die Imperialismusidee bringt +10 Absolutismus (daf�r nur noch 1 Beziehungsslot mehr)
- Die Nationalismusidee bringt +10 Absolutismus
- Die Einflussidee bringt 1 j�hrlichen Absolutismus
- Aristokratieidee rebalanced
- Die Handelsschiffidee hat 10% Handelseffizienz von Schiffen bekommen
- Die Expansionsideen wurden leicht gebufft
- Bei der Militarismusidee wurde der Kriegsm�digkeitsbonus halbiert
- Die Tengri Ideen haben 10% Cav Ratio bekommen
- Die F�higkeit die Dynastie zu verbreiten ist nun auch in der Dynastieidee (nicht mehr Spionage) (Erste Idee)
- Ein bisschen Berater Balancing
- Wirtschaftspolitiken noch etwas besser gebalanced (Verh�ltnis von Steuer, Produktion, Handel und produzierten G�tern)

###################################################################
####### Decisions & Events
###################################################################

- Die Boni aus den Advisor Events (Disziplin & Moral) wurden auf ein normales Ma� reduziert (7,5 Moral, 3,5 Diszi)
- Die Development Decision hat mehr Entwicklungsstufen dazu bekommen (Neue Stufen ab 700,800,900 und 1000, also jetzt max 30 Entwicklung)
- Der Cooldown der Development Decision richtet sich nun nach den Zeitaltern (15,12,10,8 Jahre)
- Es gibt nun Events die die Ideengruppen bei Religionswechseln zwischen Katholisch, Reformiert und Protestantisch wechseln
- Der negative Modifier nach dem Development erh�hen wurde deutlich reduziert
- Der negative Modifier f�r das F�rdern einer Dynastie wurde deutlich reduziert (nur noch 10 AE Impact) 
- Der Cooldown f�r die Dynastief�rdern Decision richtet sich nun ebenfalls nach dem Zeitalter (15,12,10,8 Jahre)

###################################################################
####### Version 2.4.2 (8dc5)
###################################################################

###################################################################
####### Ideen & Politiken
###################################################################

- Fixed: Balancing der neuen Werte nach einem intensiveren Test

###################################################################
####### Version 2.4.1 (ac97)
###################################################################

###################################################################
####### Ideen & Politiken
###################################################################

- Fixed: Ein paar Lokalisationsprobleme
- Orthodoxe Ideen wurden verbessert
- Ein paar fehlende Politiken erg�nzt (4)
- Eine �berfl�ssige Politik gestrichen
- Staatsverwaltung hat noch einen H�ndler bekommen
- Assimilation hat statt h�heren Corekosten einen kleinen Schockverteidigungsbonus (5%) als Finisher
- Die S�ldnerheerideen geben statt dem allgemeinen Landunterhaltminus nun 5% mehr Schaden in der Feuerphase
- Die zweite Gesellschaftsidee von 25% Beziehungsverbesserungsbonus auf 15% gesenkt
- Die Administration infiltrieren braucht nun 50 Spionagenetzwerk und dauert nur noch 8 Monate an! (war vorher zu stark)
- Die Wahrscheinlichkeiten nach denen die KI die Ideen w�hlt wurden nochmal deutlich �berarbeitet. Bis auf wenige Ausnahme sind die Kombinationen sehr random

###################################################################
####### Version 2.4.0 (0d48)
###################################################################

###################################################################
####### Ideen & Politiken
###################################################################

- Zwei neue Milit�rische Ideengruppen: Taktische Idee und Militarismus
- Das Balancing zwischen Galleerenidee und Gro�schiffidee wurde verfeinert 
- Die Handelsschiffidee wurde gebufft
- Die Politikkombinationen wurde im Balancing noch einmal deutlich �berarbeitet. Die milit�rischen Ideengruppen geben bis auf wenige Ausnahmen die gleiche Anzahl von m�glichen guten Politikkombinationen
- Staatsverwaltung, Administrativ und Innovativ wurden gebufft
- Die Vanilla Milit�radvisor wurden etwas generved (analog zum Ideenbonus)
- 8 neue Beratertypen
- Staatsverwaltungsideen zu den m�glichen Ideengruppen hinzugef�gt, die man braucht um die Regierung zu reformieren


###################################################################
####### Version 2.3.0 (ca50)
###################################################################

###################################################################
####### Ideen & Politiken
###################################################################

- Die Spionageideen haben eine Decision bekommen, mit denen Monarchien ihre Dynastie in andere L�nder ohne Erben verbreiten k�nnen
- Die Diplomatieideen wurden in Dynastische Ideen umbenannt. Bei Beendigung dieser Ideengruppe erh�lt man einen PU Kriegsgrund gegen alle L�nder mit der eigenen Dynastie
- Einflussideen etwas gebufft
- Ein paar Probleme mit dem relations_decay_of_me gel�st
- Die meisten der speziellen religi�sen Ideengruppen geben nun auch einen Missionar mehr
- Die koptische Religion hat nun keinen Zugriff mehr auf die generic Religionsidee
- Die nordische Religion hat nun Zugriff auf den K�steninvasionskriegsgrund


###################################################################
####### Version 2.2.0 (ca50)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Spieldateien an den neuen Patch angepasst
- Es gibt nun Events, die die Regierungsideengruppen (Monarchie, Republik etc) je nachdem welche Regierungsform man hat automatisch austauschen (keine Machtpunkteverluste)
- Handelswerte in der Defines so ge�ndert, dass kleine L�nder mit ihrer Macht der Karawane aus Inlandshandelzonen weniger abziehen k�nnen.
- Die Development Decision erh�ht die Entwicklung nun nur in Core Provinzen

###################################################################
####### Ideen & Politiken
###################################################################

- Koptische Ideengruppe hinzugef�gt
- Gro�es Politiken Rebalancing
- Man kann Politiken nun nach 3 Jahren tauschen
- Der Leader Fire Bonus ist von Offensiv nach Defensiv gewandert
- Der Man�verbonus ist von Defensiv auf Offensiv gewandert
- Die Shintoideen haben nun Missionarsst�rke bekommen (keine Diszi mehr)
- Qualit�tsideen leicht gebufft (2.5 Kampffertigkeiten mehr auf alles)
- Die Monarchieideen geben nun 5% Moral mehr
- Die Gesellschaftsidee bringt 2.5% Moral weniger
- Kriegsproduktionsidee gebufft
- Festungsideen etwas neu austariert (keine siege ability mehr, daf�r Artilleriekampffertigkeiten)
- Handelsschiffideen das Forcelimit leicht neu austariert
- Die Spionageideen haben etwas Handelseffizienz bekommen (haupts�chlich um Embargos gegen nicht Rivalen zu erleichtern)
- Die Core Kosten Boni wurden in Relation zu den Mali durch erh�hte Corekosten rebalanced
- Assimilation: Reihenfolge der Ideen etwas getauscht
- Die Wehrpflichtidee wurde leicht verbessert
- Der Humanist (Berater) gibt nun Institutionen �bernahmekosten
- S�ldnderidee den S�lnderzahlbonus leicht genervt
- Staatsverwaltung gibt nun ein paar Institutionenboni

###################################################################
####### Version 2.1.1 (6745)
###################################################################


###################################################################
####### Allgemein
###################################################################


- Quanitt�tsideen wieder nahezu auf das alte Level gebufft
- S�ldnerheerideen etwas besser
- Tooltip geupdatet (die Burgher Boni in den Ideen mussten in die letzte Idee der Ideengruppe verschoben werden, sonst gabs Bugs)
- Weniger verf�gbare S�ldner
- Seekrieg-Kriegsgrund hinzugef�gt (Kampf um Maritime Vorherschaft, �hnlich wie der Rivalenkrieg)
- Festungs Ideen sind nun etwas attraktiver geworden
- Noch ein wenig Politikenbalancing

###################################################################
####### Version 2.1.0 (1f05)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Ein paar Beschreibungen gefixt
- Die Estate Boni die die Ideen geben an das neue Berechnungssystem angepasst
- Galeeren durch R�ckkehr zum alten Feuersystem wieder spielbar gemacht (Frontbreite = 750)
- Tarife erh�hen und senken kostet nur noch 10/5 Adminpunkte
- Westernisierung etwas verbilligt und man braucht nur noch 3 Techs hinten dran zu sein um zu starten
- Die Spionageaktionen gr��ten Teils im DIP Tech deutlich nach vorne geholt
- Die Ideengruppenwahl muss nun ausbalanciert sein: Man kann nur noch alle 3 Ideen eine Milit�ridee nehmen

###################################################################
####### Ideen & Politiken
###################################################################

- 7 neue religi�se Ideengruppen (Dharmisch (Hindu), Nordisch, Tengri, Buddhismus, Shinto, Konfuzianismus, Katharisch)
- Ein paar Politiken etwas besser gebalanced
- Kolonialimperiumsideen reduzieren nun ein wenig Freiheitsstreben, au�erdem ein paar Werte getauscht
- Hat man die Maritime Idee beendet, kann man auch als nicht Nordafrikanische Nation K�sten raiden
- Die Galeerenidee bringt mehr Forcelimit
- Die Wahrscheinlichkeit mit der die KI die Entwicklungsideen/Festungsideen nimmt etwas reduziert
- Die Handelsschiff/Galeeren/Gro�schiffideen schlie�en sich nun gegenseitig aus
- Diplomatie- und Spionageidee gebufft
- Assimilationsideen etwas verbessert

###################################################################
####### Version 2.0.2 (d927)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Ein Bug bei den Einflussideen gefixt


###################################################################
####### Version 2.0.1 (aade)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Dateien an den neuen Patch angepasst

###################################################################
####### Version 2.0.0 (732d)
###################################################################


###################################################################
####### Allgemein
###################################################################

- Fixed: Ein Problem bei den die speziellen religi�sen Ideen nicht alle Politiken freigeschaltet haben die sie sollten
- Fixed: Decisions, die die Autokratieidee zum Feuern brauchten wurden korrigiert
- 3 neue Beratertypen (Minus Korruption, Minus Staatsunterhalt (Admin), Koloniewachstum (Dip)
- Die KI muss nun 25% weniger f�r ihre Ideen bezahlen, da sie ihre Monarchenpunkte nicht so gut managen konnte wie menschliche Spieler
- Extended Timeline Addon nun verf�gbar

###################################################################
####### Ideen
###################################################################

- Es gibt 3 neue Ideen: Galeerenfokus, Gro�schifffokus und Handelsschifffokus, ersetzen die alte Naval Idee (in Milit�r)
- Die Ideengruppenevents an die neuen Ideen angepasst (die alten Events der naval_ideas gelten f�r Gro�schiffe und Galeeren, die Handelsschiffidee triggert m�glicherweise die Events der Handelsideengruppe)
- Disziplinboni in den Ideen etwas generfed
- Die Orthodoxen Ideen haben noch einen Bonus auf Staatsunterhalt bekommen
- Die Baukostenreduktion in den Development Ideen wurde von 20 auf 15% reduziert
- Bei den Expansionsideen wurde der 10% Manpowerbonus gestrichen, daf�r gibt es nochmal 5 Staaten
- Die Kolonialimperiumideen geben nun einen Kolonisten weniger, daf�r gibt es noch einmal mehr Staaten


###################################################################
####### Politiken
###################################################################

- 270 neue Politiken, das Politiksystem lehnt sich nun an Vanilla wieder an, wobei jede Idee aus einer Kategorie mit jeder anderen Idee aus den beiden anderen Kategorien eine Politik freischaltet
- Disziplin Politiken etwas generfed
- Maximale Anzahl an Politiken auf 7 erh�ht
- Neues Politikeninterface (vielen Dank an Lord Satyr)

###################################################################
####### Version 1.6.1 (d3e3)
###################################################################


###################################################################
####### Ideen
###################################################################

- Anpassung der neuen Werte f�r die alten Vanilla Ideen
- Staatsverwaltung senkt nun den Unterhalt der Staatsgebiete
- Corekostenreduktion in Staatsverwaltung halbiert, daf�r kann man zus�tzliche Gebiete halten, au�erdem gibts hier Korruptionssenkung
- Die Flottenbasis Idee gibt nun auch Seeleute (anstatt der Kriegspunktkostenreduktion f�r Provinzen)
- Die Justizidee nochmal etwas �berarbeitet
- Die Kolonialimperiumidee gibt nun in der f�nften Idee Boni auf Seeleute
- Noch ein Lokalisationsproblem bei den Politiken gel�st


###################################################################
####### Version 1.6 (f6aa)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Dateien an den neuen Patch angepasst

###################################################################
####### Ideen
###################################################################

- Justizideen deutlich gebufft
- Die Gesundheitsideen wurden verbessert
- Bei den Wehrpflichtideen wurde der Milit�rtechbonus auf 7,5% reduziert, au�erdem tauschen die erste und dritte Idee die Pl�tze
- Die S�ldnerheerideen ziehen keine Manpower mehr ab, au�erdem wurde der S�ldnerunterhalt noch etwas gesenkt
- In der Expansionsidee wurden die komplett abgeschafften Kosten f�r Verst�rkungen entfernt, daf�r jetzt -10 Landunterhalt und -10 Marineunterhalt
- Ein Problem mit der Development Decision gefixt, das auftrat wenn man als Land weniger als 20 Development hatte
- Die Missionarsst�rke der Orthodoxen Ideen wurde erh�ht (von 2 auf 3)




###################################################################
####### Version 1.5 (b692)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Die Development Decision feuert nun sofort ein Event, bringt etwas bessere Performence und fixt einen kleinen Bug, der auftreten konnte
- Weiteres Feintuning am Balancing
- Ein Localisationsproblem gel�st




###################################################################
####### Version 1.4 (1bb2)
###################################################################

###################################################################
####### Allgemein
###################################################################

- Ein weiterer Burg mit den B�rgern gefixt. Funktioniert jetzt endlich wie es soll



###################################################################
####### Version 1.3 (49d6)
###################################################################

###################################################################
####### Allgemein 
###################################################################

- Ideen kosten nun 250 Punkte
- Die Orthodoxen Ideen wruden etwas verbessert
- Bei den islamischen Ideen wurde ein wenig Missionarsst�rke durch Toleranz der H�retiker getauscht
- Fixed: Interface der Ideen
- Gesundheitsideen wurden etwas gebufft
- Allgemeines Balancing von vielen Ideen noch etwas angepasst
- Fixed: B�rger wurden nicht richtig angezeigt
- Die KI nimmt nun etwas priorisierter Milit�rideen
- Die KI wird nun wichtige milit�rische Politiken deutlich priorisierter ausw�hlen
- Land Unterhalt von 1% pro erforschter Landtechnologie auf 3% erh�ht